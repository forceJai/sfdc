# Communities Architecture

## White Papers

* [Getting Started with Communities](http://resources.docs.salesforce.com/200/12/en-us/sfdc/pdf/salesforce_communities_implementation.pdf)

## Webinars
* [Developing Public Websites With Force.com Sites](https://www.youtube.com/watch?v=icfkAeMf_e4)

## Articles
* [Authenticating Users on Force.com Sites](https://developer.salesforce.com/page/Authenticating_Users_on_Force.com_Sites)
