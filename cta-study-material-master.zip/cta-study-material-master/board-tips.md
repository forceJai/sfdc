# Board Tips & Tricks

## Webinars

* [Technical Architect Certification: Learn From Our Experts](https://www.youtube.com/watch?v=yzDOrbc3pQI)

## Independent Articles

* [Eric Santiago - Salesforce Technical Architect Certification; Part 2 - Review Board](http://www.ericsantiago.com/eric_santiago/2012/05/salesforce-technical-architect-certification-part-2-review-board.html)
* [Bob Buzzard - Certified Salesforce Technical Architect](http://bobbuzzard.blogspot.co.uk/2012/02/certified-salesforce-technical.html)
* [Wes Nolte - Salesforce Certified Technical Architect](http://th3silverlining.com/2013/07/24/salesforce-certified-technical-architect/)
* [Gregory Cook - My Journey to Salesforce.com Certified Technical Architect](http://enterpriseforcearchitect.com/2014/03/12/my-journey-to-salesforce-com-certified-technical-architect/)
* [Lorenzo Frattini - Salesforce Certified Technical Architect](http://lofrattini.io/salesforce-certified-technical-architect/)
