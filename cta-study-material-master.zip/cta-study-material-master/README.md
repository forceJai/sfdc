# Salesforce CTA Study Material
This is a collection of publicly available study material for preparing for Salesforce Certified Technical Architect. This repository is a work in progress and I am constantly adding new relevant resources as I encounter them.

## Salesforce Architect Academy
* [Salesforce Architect Academy Complete Resource Guide](https://www.inkling.com/store/book/architect-academy-salesforce/)
